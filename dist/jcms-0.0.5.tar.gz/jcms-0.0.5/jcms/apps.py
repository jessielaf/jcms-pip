from django.apps import AppConfig


class JcmsConfig(AppConfig):
    name = 'jcms'
