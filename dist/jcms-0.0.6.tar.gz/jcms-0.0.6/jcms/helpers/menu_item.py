class MenuItem(object):
    title = ''
    url_name = ''

    def __init__(self, title, url_name):
        self.title = title
        self.url_name = url_name
